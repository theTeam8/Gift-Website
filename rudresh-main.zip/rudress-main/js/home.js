document.addEventListener("DOMContentLoaded", function () {
  var elems = document.querySelectorAll(".tabs");
  var instance = M.Tabs.init(elems, {
    swipeable: false,
  });
});

document.addEventListener("DOMContentLoaded", function () {
  var elems = document.querySelectorAll(".carousel");
  var instances = M.Carousel.init(elems, {
    fullWidth: true,
    indicators: true,
    duration:200
  });
});
